﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    private BoxCollider2D boxCollider;
    private Animator animator;
    private Vector3 moveDelta;
    private Rigidbody2D rb;
    private bool isDead = false;
    private bool isKnockedBack = false;

    public float walkMultiplier = 1.0f;
    public float runMultiplier = 1.5f;
    public float knockbackForce = 5f;
    public float knockbackDuration = 0.3f;

    private HealthBar healthBar;

    private void Start()
    {
        boxCollider = GetComponent<BoxCollider2D>();
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();

        if (GameManager.Instance != null && GameManager.Instance.currentHealth <= 0)
        {
            GameManager.Instance.currentHealth = GameManager.Instance.maxHealth;
        }

        healthBar = FindObjectOfType<HealthBar>();
        if (healthBar != null)
        {
            healthBar.SetMaxHealth(GameManager.Instance.maxHealth);
            healthBar.SetHealth(GameManager.Instance.currentHealth);
        }
    }

    private void FixedUpdate()
    {
        if (isDead || isKnockedBack) return;

        float x = Input.GetAxisRaw("Horizontal");
        float y = Input.GetAxisRaw("Vertical");
        moveDelta = new Vector3(x, y, 0);

        if (moveDelta.x > 0)
            transform.localScale = Vector3.one;
        else if (moveDelta.x < 0)
            transform.localScale = new Vector3(-1, 1, 1);

        bool isRunning = Input.GetKey(KeyCode.LeftShift);
        bool isCrouching = Input.GetKey(KeyCode.LeftControl);

        animator.SetBool("IsRunning", isRunning);
        animator.SetBool("IsCrouching", isCrouching);
        animator.SetFloat("Speed", moveDelta.sqrMagnitude);

        float speedMultiplier = walkMultiplier;
        if (isRunning) speedMultiplier = runMultiplier;
        if (isCrouching) speedMultiplier = walkMultiplier * 0.5f;

        animator.speed = isRunning ? 1.5f : 1.0f;

        transform.Translate(moveDelta * speedMultiplier * Time.fixedDeltaTime);
    }

    public void TakeDamage(int amount, Vector2 sourcePosition)
    {
        if (isDead) return;

        GameManager.Instance.currentHealth -= amount;
        GameManager.Instance.currentHealth = Mathf.Clamp(GameManager.Instance.currentHealth, 0, GameManager.Instance.maxHealth);

        if (healthBar != null)
            healthBar.SetHealth(GameManager.Instance.currentHealth);

        if (GameManager.Instance.currentHealth <= 0)
        {
            StartCoroutine(Die());
        }
        else
        {
            StartCoroutine(ApplyKnockback(sourcePosition));
        }
    }

    private IEnumerator ApplyKnockback(Vector2 sourcePosition)
    {
        isKnockedBack = true;

        Vector2 knockDir = (rb.position - sourcePosition).normalized;
        rb.velocity = knockDir * knockbackForce;

        yield return new WaitForSeconds(knockbackDuration);

        rb.velocity = Vector2.zero;
        isKnockedBack = false;
    }

    public void Heal(int amount)
    {
        if (isDead) return;

        GameManager.Instance.currentHealth = Mathf.Min(GameManager.Instance.currentHealth + amount, GameManager.Instance.maxHealth);

        if (healthBar != null)
            healthBar.SetHealth(GameManager.Instance.currentHealth);
    }

    private IEnumerator Die()
    {
        isDead = true;
        animator.SetTrigger("Die");

        yield return new WaitForSeconds(1.5f);
        SceneManager.LoadScene("MainMenu");
    }
}


