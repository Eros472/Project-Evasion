public enum InventoryItemType
{
    None,
    Dagger,
    Bow,
    HealthPack,
    Key
}

